"""
Future extensions for OptiPFair pruning methods.

This package will contain additional pruning methods in future releases.
"""